/*******************************************************
www.ichibot.id
copyright ICHIBOT @2021
Email : team.ichibot@gmail.com
dilarang dicopy atau dipakai atau di perjual belikan
untuk tujuan komersil tanpa seijin dari Ichibot
atau kamu akan dikutuk menjadi batu
v1.0 25 Maret 2021
********************************************************/

#ifndef IchibotUltimate5_LED_SMD_h
#define IchibotUltimate5_LED_SMD_h
#include <Arduino.h>

// include the library code:
#include <SPI.h>
#include <Wire.h>
#include <EEPROM.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH1106.h>
#include <FastLED_2.h>
#define LED_PIN     12
#if _RGB_SENSOR_
#     define NUM_LEDS    19 //led rgb 17, buzzer 1 di pin G leds ke 15 // mrc 19 normal 18
#     define LED_INDEX_BUZZER  15
#     define LED_INDEX_TAIL_R  16
#     define LED_INDEX_TAIL_L  17
#else
#     define NUM_LEDS    5//led depan 0, buzzeer di pin G leds ke 1 , tail 2,3 //// mrc 5 normal 4
#     define LED_INDEX_BUZZER  1
#     define LED_INDEX_TAIL_R  2
#     define LED_INDEX_TAIL_L  3
#endif
#define LED_INDEX_TAIL_L  3
#define BRIGHTNESS  255
#define LED_TYPE    WS2812B
#define COLOR_ORDER GRB
CRGB leds[NUM_LEDS];
CRGB LAST_LEDS[NUM_LEDS];
#define FRAMES_PER_SECOND 60
#define COOLING  55

byte WS1_PORT_1 = 0, WS1_PORT_2 = 0, WS1_PORT_3 = 0, WS1_PORT_4 = 0;
void Task_fastled_code( void * pvParameters ) {
  byte is_same;
  while (1) {
    is_same = true;
    for (int i = 0 ; i < NUM_LEDS; i++) {
      if (LAST_LEDS[i] != leds[i]) {
        LAST_LEDS[i] = leds[i];
        is_same = false;
      }
    }
    if (is_same == false) {
      FastLED.show();
    }
    vTaskDelay(5 / portTICK_PERIOD_MS);
  }
}

TaskHandle_t Task_fastled;

#define SSD1306_WHITE WHITE
#define SSD1306_BLACK BLACK
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define LCD_ADDRESS 0x3C
#define PIN_ADC_BUTTON_L 36
#define PIN_ADC_BUTTON_R 39

#define S0 14
#define S1 27
#define S2 15
#define S3 13
#define OUT 33
#define PIN_EN_SENSOR 0
#define PWM_FWD_MOTOR_L       12 //PWM CH0
#define PWM_BWD_MOTOR_L       13 //PWM CH1
#define PWM_FWD_MOTOR_R       14 //PWM CH2
#define PWM_BWD_MOTOR_R       15 //PWM CH3
#define PIN_FWD_MOTOR_L       4 //d7 Forward IN
#define PIN_BWD_MOTOR_L       16 //d6 Backward IN
#define PIN_FWD_MOTOR_R       18 //d5 Forward IN
#define PIN_BWD_MOTOR_R       26 //d4 Backward IN
#define OLED_RESET     -1
Adafruit_SH1106 lcd(-1, -1);

#define PIN_BATT_SENSOR A0
#define PIN_SERVOL 5
#define PIN_SERVOR 2
#define PIN_EXTENGUISHER 11

#define NUM_CP 5
#define ACTIVE_LOW 0
#define ACTIVE_HIGH 1

//Servo servo_lift;
//Servo servo_grip;

#define TARUH   0
#define NORMAL  1
#define AMBIL   2

#define PID_0 0
#define PID_1 1
#define PID_2 2

#define CP_0 0
#define CP_1 1
#define CP_2 2
#define CP_3 3
#define CP_4 4
#define CP_5 5


#define KIPAS_OFF 0
#define KIPAS_ON  1

#define MOTION ACTION_NOT_USE_SENSOR
#define ACTION ACTION_USE_SENSOR

#define GARIS_HITAM 0
#define GARIS_PUTIH 1

#define ACTION_NOT_USE_SENSOR 1
#define ACTION_USE_SENSOR 0

#define OR    0
#define EQUAL 1
#define XOR   2

#define SENSOR_SEMUA          0b11111111111111, 0b00000000000000, OR
#define SENSOR_SEMUA_KENA     0b11111111111111, 0b00000000000000, EQUAL
#define SENSOR_KOSONG         0b00000000000000, 0b00000000000000, EQUAL
#define SENSOR_KIRI           0b11000000000000, 0b00000000000000, OR
#define SENSOR_KANAN          0b00000000000011, 0b00000000000000, OR
#define SENSOR_KIRI_KANAN     0b11000000000000, 0b00000000000011, XOR
#define SENSOR_KIRI_TENGAH    0b11000000000000, 0b00000111100000, XOR
#define SENSOR_KANAN_TENGAH   0b00000000000011, 0b00000111100000, XOR
#define SENSOR_SIKU_KANAN     0b00000000001110, 0b00000111100000, XOR
#define SENSOR_SIKU_KIRI      0b01110000000000, 0b00000111100000, XOR

unsigned int btn_adcL, btn_adcR;
boolean polMotor_L, polMotor_R;
int adcValue[14];
char buff[100];

struct dataPID {
  byte Kp;
  byte Kd;
  byte Ki;
  byte DT;
  byte PMax;
  int PMin;
};

struct dataEEPROM {
  unsigned int LIMIT_VALUE_SENSOR[14];
  byte thisCheckPoint;
};

struct dataSetting {
  int speed;
  byte checkPoint[NUM_CP];
  byte stopIndex;
  byte sensor_linewidth;
  byte sensor_sensivity;
  byte lineColor;
  byte numPID;
};

struct dataIndex {
  byte action;
  unsigned int sensorBitValue[2];
  byte modeSensor;
  int L, R, D;
  byte SA;
  unsigned int TA;
  byte lineColor;
  byte fanState, servo_position;
  byte numPID;
};

#define TOTAL_INDEX 99
#define NUM_PID 6
dataIndex ramIndexData[TOTAL_INDEX];
dataPID listPID[NUM_PID];
dataSetting setting;
dataEEPROM eep;

static const unsigned char PROGMEM  botLogo[1024] = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x60, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0xc0, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0x80, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0xff, 0x80, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x80, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x18, 0x66, 0x1f, 0xcc, 0xe0, 0x70, 0xe1, 0xfc, 0xfc, 0x03, 0xfc, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x18, 0x66, 0x1f, 0xcc, 0xf0, 0xf0, 0xe1, 0xfc, 0xfc, 0x07, 0xfe, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x30, 0xcc, 0x06, 0x19, 0xb1, 0xe1, 0xb0, 0x61, 0x80, 0x04, 0x7f, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x30, 0xcc, 0x06, 0x19, 0xb3, 0x61, 0xb0, 0x61, 0x80, 0x00, 0x7f, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x30, 0xcc, 0x06, 0x19, 0xb3, 0x63, 0x30, 0x61, 0xf8, 0x00, 0x7f, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x30, 0xcc, 0x06, 0x19, 0xb6, 0x63, 0x30, 0x61, 0xf8, 0x00, 0x7e, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x30, 0xcc, 0x06, 0x19, 0xb6, 0x67, 0xf0, 0x61, 0x80, 0x00, 0xfe, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x31, 0x98, 0x0c, 0x33, 0x1c, 0xc7, 0xf8, 0xc3, 0x00, 0x01, 0xfc, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x3f, 0x9f, 0x8c, 0x33, 0x1c, 0xcc, 0x18, 0xc3, 0xf0, 0x23, 0xf8, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x1e, 0x1f, 0x8c, 0x33, 0x18, 0xcc, 0x18, 0xc3, 0xf0, 0x7f, 0xf0, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3f, 0x80, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0xa0, 0x02, 0x08, 0x20, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0x02, 0x00, 0x20, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x44, 0x51, 0x14, 0x44, 0x27, 0x2c, 0xac, 0x77, 0x09, 0xa0, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x4a, 0x52, 0x94, 0xa4, 0x28, 0xb2, 0xb2, 0x8a, 0x0a, 0x60, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x2a, 0x8a, 0xa2, 0xa8, 0x28, 0x22, 0xa2, 0x8a, 0x0a, 0x20, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x2a, 0x8a, 0xa2, 0xa8, 0x28, 0x22, 0xa2, 0x8a, 0x0a, 0x20, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x11, 0x04, 0x41, 0x10, 0x28, 0xa2, 0xb2, 0x8a, 0x0a, 0x60, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x11, 0x04, 0x41, 0x10, 0xa7, 0x22, 0xac, 0x73, 0x29, 0xa0, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

class IchibotUltimate5_LED_SMD {
private:

public:
  void setIndex(byte index, unsigned int sensor0, unsigned int sensor1, byte modeSensor, byte action,  int L , int R , unsigned int D ,
    byte lineColor = GARIS_HITAM, byte SA = 150, unsigned int TA  = 0, byte numPID = 0,  byte kipas = 0, byte servo_pos = NORMAL) {
      ramIndexData[index].sensorBitValue[0] = sensor0;
      ramIndexData[index].sensorBitValue[1] = sensor1;
      ramIndexData[index].L = L;
      ramIndexData[index].R = R;
      ramIndexData[index].D = D;
      ramIndexData[index].SA = SA;
      ramIndexData[index].TA = TA;
      ramIndexData[index].modeSensor = modeSensor;
      ramIndexData[index].action = action;
      ramIndexData[index].numPID = numPID;
      ramIndexData[index].fanState = kipas;
      ramIndexData[index].servo_position = servo_pos;
      ramIndexData[index].lineColor = lineColor;
    }

    void StopAtIndex(byte Index) {
      setting.stopIndex = Index;
    }

    void setFan(byte state) {
      digitalWrite(PIN_EXTENGUISHER, state > 0 ? HIGH : LOW);
    }

    void setCheckPoint(byte num, byte index) {
      if (num < NUM_CP) {
        setting.checkPoint[num] = index;
      }
    }

    void polaritasMotor(boolean left, boolean right) {
      polMotor_L = left;
      polMotor_R = right;
    }

    void setPID(byte num, byte Kp, byte Ki, byte Kd, byte dt, byte PMax, int PMin) {
      if (num < NUM_PID) {
        listPID[num].Kp = Kp;
        listPID[num].Ki = Ki;
        listPID[num].Kd = Kd;
        listPID[num].DT = dt;
        listPID[num].PMax = PMax;
        listPID[num].PMin = PMin;
      }
    }

    void setSensorSensivity(byte sensivity) {
      setting.sensor_sensivity = sensivity;
    }

    void setSpeed(byte spd) {
      setting.speed = spd;
    }

    void readEEPROM() {
      EEPROM.get(0, eep);
    }

    void setBuzzer(bool stats){
      if (stats == true){
        leds[LED_INDEX_BUZZER] = CRGB(WS1_PORT_1, 255, WS1_PORT_2);
      } else {
        leds[LED_INDEX_BUZZER] = CRGB(WS1_PORT_1, 0, WS1_PORT_2);
      }
    }

    void set_tail_led(CRGB l_color, CRGB r_color) {
      leds[LED_INDEX_TAIL_R] = r_color;
      leds[LED_INDEX_TAIL_L] = l_color;
    }

    void writeEEPROM() {
      EEPROM.put(0, eep);
      EEPROM.commit();
    }

    void begin() {
      Serial.begin(115200);
      lcd.begin(SH1106_SWITCHCAPVCC, 0x3C);
      Wire.setClock(3400000);
      lcd.setRotation(2);
      lcd.setTextColor(SSD1306_WHITE);

      pinMode(PIN_ADC_BUTTON_L, INPUT);
      pinMode(PIN_ADC_BUTTON_R, INPUT);

      ledcSetup(PWM_BWD_MOTOR_L, 1000, 13);
      ledcSetup(PWM_FWD_MOTOR_L, 1000, 13);
      ledcSetup(PWM_BWD_MOTOR_R, 1000, 13);
      ledcSetup(PWM_FWD_MOTOR_R, 1000, 13);

      ledcAttachPin(PIN_BWD_MOTOR_L, PWM_BWD_MOTOR_L);
      ledcAttachPin(PIN_FWD_MOTOR_L, PWM_FWD_MOTOR_L);
      ledcAttachPin(PIN_BWD_MOTOR_R, PWM_BWD_MOTOR_R);
      ledcAttachPin(PIN_FWD_MOTOR_R, PWM_FWD_MOTOR_R);

      pinMode(LED_PIN, OUTPUT);
      FastLED.addLeds<LED_TYPE, LED_PIN, COLOR_ORDER>(leds, NUM_LEDS);
      FastLED.setBrightness(  BRIGHTNESS );
      Serial.println("Init MULTICORE");
      xTaskCreatePinnedToCore(
        Task_fastled_code,   /* Task function. */
        "Task_fastled_code",     /* name of task. */
        5000,       /* Stack size of task */
        NULL,        /* parameter of the task */
        0,                  /* priority of the task */
        &Task_fastled,      /* Task handle to keep track of created task */
        0);          /* pin task to core 0 */
        
      Serial.println("Init Sensor");
      init_sensor();
      EEPROM.begin(512);
      readEEPROM();
      lcd.clearDisplay();
      lcd.drawBitmap(0, 0, botLogo, 128, 64, 1);
      lcd.display();
      delay(1000);
      lcd.clearDisplay();
      setBuzzer(true);
      delay(100);
      setBuzzer(false);
      setCheckPoint (CP_0, 0);
      leds[0] = CRGB(0,0,0);
      }

      void ichibotLoop() {
        while (1) {
          btn_adcL = analogRead(PIN_ADC_BUTTON_L);
          btn_adcR = analogRead(PIN_ADC_BUTTON_R);

          displaySensor();

          lcd.drawRoundRect(50, 0, 78, 13, 3,  WHITE);

          lcd.setCursor(57, 3);
          sprintf(buff, "CP:%.2d(i:%.2d)", eep.thisCheckPoint, setting.checkPoint[eep.thisCheckPoint]);
          lcd.print(buff);

          lcd.drawRoundRect(0, 0, 47, 13, 3,  WHITE);
          lcd.setCursor(3, 3);
          sprintf(buff, "SPD:%.3d", setting.speed);
          lcd.print(buff);

          if (btn_adcR > 2300 && btn_adcR < 3500) {
            eep.thisCheckPoint++;
            if (eep.thisCheckPoint > 5) eep.thisCheckPoint = 5;
            delay(150);
            writeEEPROM();
          }

          if (btn_adcR > 1600 && btn_adcR < 2000 && eep.thisCheckPoint != 0) {
            eep.thisCheckPoint --;
            if (eep.thisCheckPoint < 0) eep.thisCheckPoint = 0;
            delay(150);
            writeEEPROM();
          }

          if (btn_adcL > 2300 && btn_adcL < 3500) {
            setting.speed += 5;
            if (setting.speed > 255) setting.speed = 255;
            delay(100);
          }

          if (btn_adcL > 1600 && btn_adcL < 2000) {
            setting.speed -= 5;
            if (setting.speed < 0) setting.speed = 0;
            delay(100);
          }

          lcd.drawRoundRect(0, 51, 47, 13, 3,  WHITE);
          lcd.setCursor(5, 51 + 3);
          lcd.print("OK");
          lcd.fillTriangle(
            19, 51 + 3,
            19, 51 + 3 + 6,
            19 + 3, 51 + 3 + 3, WHITE);
            lcd.setCursor(26, 51 + 3);
            lcd.print("Cal");

            lcd.drawRoundRect(50, 51, 78, 13, 3,  WHITE);
            lcd.setCursor(89, 51 + 3);
            lcd.print("CANCEL");
            lcd.fillTriangle(
              85, 51 + 3,
              85, 51 + 3 + 6,
              85 - 3, 51 + 3 + 3, WHITE);
              lcd.setCursor(62, 51 + 3);
              lcd.print("Run");


              if (btn_adcL > 4000) {
                delay(300);
                calibrateSensor();
              }

              if (btn_adcR > 4000) {
                while (btn_adcR > 4000) {
                  btn_adcL = analogRead(PIN_ADC_BUTTON_L);
                  btn_adcR = analogRead(PIN_ADC_BUTTON_R);
                  lcd.setCursor(22, 10);
                  lcd.print("Ready Position");
                  lcd.setCursor(22, 35);
                  lcd.print("Release button");
                  lcd.setCursor(28, 45);
                  lcd.print("to RUN Robot");

                  lcd.display();
                  lcd.clearDisplay();
                }
                lcd.clearDisplay();
                lcd.setTextSize(2);
                lcd.setCursor(10, 25);
                lcd.print("Robot RUN");
                lcd.setTextSize(1);
                lcd.display();
                break;
              }

              lcd.display();
              lcd.clearDisplay();
            }

            byte thisRunIndex = 0;
            int dataSensor;
            thisRunIndex = setting.checkPoint[eep.thisCheckPoint];
            dataIndex mem  = ramIndexData[thisRunIndex];
            int normalSpeed =  setting.speed;
            setting.lineColor = mem.lineColor;
            int timerSpeed;
            long timer;

            while (1) {
              btn_adcL = analogRead(PIN_ADC_BUTTON_L);
              btn_adcR = analogRead(PIN_ADC_BUTTON_R);
              mem  = ramIndexData[thisRunIndex];
              dataSensor = readSensor();
              byte do_action = 0;
              if ( mem.action == ACTION_NOT_USE_SENSOR) {
                do_action = 1;
              } else if (mem.action == ACTION_USE_SENSOR ) {
                if ( mem.modeSensor == XOR) {
                  if (dataSensor & mem.sensorBitValue[0]) {
                    if (dataSensor & mem.sensorBitValue[1])  {
                      do_action = 2;
                    }
                  }
                } else if (mem.modeSensor == OR) {
                  if (dataSensor & mem.sensorBitValue[0]) { 
                    do_action = 3;
                  }
                } else if (mem.modeSensor == EQUAL) {
                  if (dataSensor == mem.sensorBitValue[0]) {
                    do_action = 4;
                  }
                }
              }

              if (do_action) {
                set_tail_led(CRGB(255,0,0), CRGB(255,0,0));
                setBuzzer(true);
                setMotor(mem.L, mem.R);
                delay(mem.D);
                setFan(mem.fanState);
                //setServo(mem.servo_position);

                if (mem.action == ACTION_USE_SENSOR ) {
                  dataSensor = readSensor();
                  while (dataSensor == 0) {
                    dataSensor = readSensor();
                  }
                }
                setBuzzer(false);
                set_tail_led(CRGB(0,0,0), CRGB(0,0,0));

                timer = mem.TA;
                setting.numPID = mem.numPID;
                setting.lineColor = mem.lineColor;
                long lastmsg = millis();
                setting.speed = mem.SA;
                set_tail_led(CRGB(0,255,0), CRGB(0,255,0));
                while (1) {
                  dataSensor = readSensor();
                  followLine(dataSensor);
                  btn_adcL = analogRead(PIN_ADC_BUTTON_L);
                  btn_adcR = analogRead(PIN_ADC_BUTTON_R);
                  if (btn_adcL > 4000 || btn_adcR > 4000) {
                    setMotor(0, 0);
                    delay(300);
                    break;
                  }
                  if ((millis()  - lastmsg) > timer) break;
                }
                set_tail_led(CRGB(0,0,0), CRGB(0,0,0));

                timer = 0;
                setting.speed = normalSpeed;

                if (thisRunIndex >= setting.stopIndex) {
                  setMotor(0, 0);
                  for(byte u = 0; u<3 ;u++){
                    setBuzzer(true);
                    delay(100);
                    setBuzzer(false);
                    delay(50);
                  }
                  break;
                }
                thisRunIndex ++;
              }

              if (btn_adcL > 4000 || btn_adcR > 4000) {
                setMotor(0, 0);
                delay(500);
                break;
              }
              followLine(dataSensor);
            }

            while (1) {
              lcd.clearDisplay();
              lcd.setCursor(32, 10);
              lcd.print("Robot Stop");
              lcd.setCursor(38, 25);
              lcd.print("at Index");
              lcd.setTextSize(2);
              lcd.setCursor(52, 40);
              sprintf(buff, "%.2d", thisRunIndex);
              lcd.print(buff);
              lcd.setTextSize(1);
              setting.lineColor = ramIndexData[0].lineColor;

              lcd.display();
              btn_adcR = analogRead(PIN_ADC_BUTTON_R);
              if (btn_adcR > 4000) {
                thisRunIndex = 0;
                delay(300);
                break;
              }
            }

          }

          int readSensor() {
            int dataSensorBit = 0b00000000000000;
            init_sensor();
            for (int i = 1; i < 15 ; i ++) {
              select_input(i);
              adcValue[i - 1] = analogRead(OUT);
            }

            for (int i = 0; i < 14; i++) {
              if ( adcValue[i] > eep.LIMIT_VALUE_SENSOR[i]) {
                dataSensorBit = dataSensorBit  + (0b00000000000001 << i);
              }
            }

            int bufBitSensor = 0b11111111111111;
            if (setting.lineColor == GARIS_PUTIH) {
              bufBitSensor = 0b11111111111111 - dataSensorBit;
            } else {
              bufBitSensor = dataSensorBit;
            };
            return bufBitSensor;
          }

          void displaySensor() {
            int sens = readSensor();
            for (int i = 0; i < 14; i++) {
              if ((sens << i) & 0b10000000000000) {
                lcd.fillRect(10 + (8 * i), 25, 5, 13, WHITE);
              } else {
                lcd.fillRect(10 + (8 * i), 25, 5, 13, BLACK);
                lcd.fillRect(10 + (8 * i), 25 + 13 - 1, 5, 1, WHITE);
              }
            }
          }

          void select_input(byte inp) {
            digitalWrite(S0, inp & 0b0001);
            digitalWrite(S1, inp & 0b0010);
            digitalWrite(S2, inp & 0b0100);
            digitalWrite(S3, inp & 0b1000);
          }

          void init_sensor() {
            pinMode(PIN_EN_SENSOR, OUTPUT);
            digitalWrite(PIN_EN_SENSOR, HIGH);
            pinMode(S0, OUTPUT);
            pinMode(S1, OUTPUT);
            pinMode(S2, OUTPUT);
            pinMode(S3, OUTPUT);
            pinMode(OUT, INPUT);
            select_input(0);
          }

          double P = 0;
          double D = 0;
          double I = 0;
          double error = 0;
          double lastError = 0;
          unsigned long lastProcess = 0;
          double sumOut = 0;

          void followLine (int dataSensor) {
            unsigned long current_millis = millis();
            if (current_millis -  lastProcess >= listPID[setting.numPID].DT) {
              double deltaTime = (current_millis - lastProcess) / 1000.000;
              lastProcess = millis();

              switch (dataSensor) {
                case 0b00000011000000: error = 0;    break;
                case 0b00000110000000: error = 1;    break;
                case 0b00000001100000: error = -1;    break;
                case 0b00000100000000: error = 2;    break;
                case 0b00000000100000: error = -2;    break;
                case 0b00001100000000: error = 3;    break;
                case 0b00000000110000: error = -3;    break;
                case 0b00001000000000: error = 4;    break;
                case 0b00000000010000: error = -4;    break;
                case 0b00011000000000: error = 5;    break;
                case 0b00000000011000: error = -5;    break;
                case 0b00010000000000: error = 7;    break;
                case 0b00000000001000: error = -7;    break;
                case 0b00110000000000: error = 8;    break;
                case 0b00000000001100: error = -8;    break;
                case 0b00100000000000: error = 10;    break;
                case 0b00000000000100: error = -10;    break;
                case 0b01100000000000: error = 11;    break;
                case 0b00000000000110: error = -11;    break;
                case 0b01000000000000: error = 13;    break;
                case 0b00000000000010: error = -13;    break;
                case 0b11000000000000: error = 14;    break;
                case 0b00000000000011: error = -14;    break;
                case 0b10000000000000: error = 16;    break;
                case 0b00000000000001: error = -16;    break;
              }

              P = error * (double) listPID[setting.numPID].Kp;
              D = ((error - lastError) * (double) listPID[setting.numPID].Kd ) / deltaTime;

              if (dataSensor & 0b0000011100000) {
                I = 0;
                sumOut = 0;
              } else {
                sumOut += error * deltaTime;
                I = sumOut * listPID[setting.numPID].Ki;
              }

              lastError = error;
              double moveVal = P +  I + D;
              double moveLeft, moveRight;

              if (moveVal >= 0) {
                moveLeft = setting.speed - (moveVal * 1.8);
                moveRight = setting.speed + moveVal;
              } else {
                moveLeft = setting.speed - moveVal;
                moveRight = setting.speed + (moveVal * 1.8);
              }

              if (moveLeft < listPID[setting.numPID].PMin)  moveLeft = listPID[setting.numPID].PMin;
              if (moveLeft > listPID[setting.numPID].PMax)  moveLeft = listPID[setting.numPID].PMax;
              if (moveRight < listPID[setting.numPID].PMin)  moveRight = listPID[setting.numPID].PMin;
              if (moveRight > listPID[setting.numPID].PMax)  moveRight = listPID[setting.numPID].PMax;
              setMotor(moveLeft, moveRight);
            }

          }


          void calibrateSensor() {
            const int numSensor = 14;
            unsigned int minVal[numSensor], maxVal[numSensor];
            lcd.clearDisplay();
            lcd.setCursor(0, 0);
            lcd.print("Calibrate Sensor..");
            lcd.setCursor(0, 10);
            lcd.print("Please Wait");
            lcd.setCursor(0, 20);
            lcd.print("Robot Will Rotate");
            setBuzzer(true);
            delay(200);
            setBuzzer(false);

            lcd.display();
            for (int i = 0; i < numSensor; i++) {
              minVal[i] = 1023;
              maxVal[i] = 0;
            }

            delay(500);
            setMotor(40,-40);
            unsigned long LM_CAL = millis();
            while (millis() - LM_CAL < 2000) {
              int buffSens = readSensor();
              for (int i = 0; i < numSensor; i++) {
                if (adcValue[i] > maxVal[i]) {
                  maxVal[i]  = adcValue[i];
                }
                if (adcValue[i] < minVal[i]) {
                  minVal[i]  = adcValue[i];
                }
              }
            }
            setMotor(0,0);

            for (int i = 0; i < numSensor; i++) {
              eep.LIMIT_VALUE_SENSOR[i] = ((maxVal[i] - minVal[i]) * (float)((100.0 - setting.sensor_sensivity) / 100.0)) + minVal[i];
            }
            lcd.clearDisplay();
            lcd.setCursor(0, 0);
            lcd.print("Saving Calibration...");
            lcd.display();
            delay(500);
            for(byte u = 0; u<3 ;u++){
              setBuzzer(true);
              delay(100);
              setBuzzer(false);
              delay(50);
            }
            writeEEPROM();
            lcd.clearDisplay();
          }

          void analogWrite(uint8_t channel, uint32_t value, uint32_t valueMax = 255) {
            uint32_t duty = (8191 / valueMax) * min(value, valueMax);
            ledcWrite(channel, duty);
          }

          void setMotor(int LL, int RR) {
            if (polMotor_R == 0) {
              if (RR > 0) {
                analogWrite(PWM_FWD_MOTOR_R, 255 - RR);
                analogWrite(PWM_BWD_MOTOR_R, 255);
              } else {
                analogWrite(PWM_FWD_MOTOR_R, 255 );
                analogWrite(PWM_BWD_MOTOR_R, 255 + RR);
              }
            } else {
              if (RR > 0) {
                analogWrite(PWM_FWD_MOTOR_R, 255);
                analogWrite(PWM_BWD_MOTOR_R, 255 - RR);
              } else {
                analogWrite(PWM_FWD_MOTOR_R, 255 + RR);
                analogWrite(PWM_BWD_MOTOR_R, 255);
              }
            }

            if (polMotor_L == 0) {
              if (LL > 0) {
                analogWrite(PWM_FWD_MOTOR_L, 255 - LL);
                analogWrite(PWM_BWD_MOTOR_L, 255);
              } else {
                analogWrite(PWM_FWD_MOTOR_L, 255);
                analogWrite(PWM_BWD_MOTOR_L, 255 + LL);
              }
            } else {
              if (LL > 0) {
                analogWrite(PWM_FWD_MOTOR_L, 255);
                analogWrite(PWM_BWD_MOTOR_L, 255 - LL);
              } else {
                analogWrite(PWM_FWD_MOTOR_L, 255 + LL);
                analogWrite(PWM_BWD_MOTOR_L, 255);
              }
            }
          }


        };
        #endif
