visit IOTSHARING.COM for more
# esp32-sh1106-oled

This is for Arduino I just modified it for esp32
Demo 6: How to use Arduino ESP32 to display information on OLED
http://www.iotsharing.com/2017/05/how-to-use-arduino-esp32-to-display-oled.html
